interface IconProps {
    className?: string;
    size?: number;
}

export const BriefcaseIcon: React.FC<IconProps> = ({ className = "", size = 45 }) => {
    return (
        <svg
            width={ size }
            height={ size }
            viewBox="0 0 45 45"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={ className }
        >
            <path d="M37.5 13.125H7.5C5.42893 13.125 3.75 14.8039 3.75 16.875V35.625C3.75 37.6961 5.42893 39.375 7.5 39.375H37.5C39.5711 39.375 41.25 37.6961 41.25 35.625V16.875C41.25 14.8039 39.5711 13.125 37.5 13.125Z" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M30 39.375V9.375C30 8.38044 29.6049 7.42661 28.9016 6.72335C28.1984 6.02009 27.2446 5.625 26.25 5.625H18.75C17.7554 5.625 16.8016 6.02009 16.0984 6.72335C15.3951 7.42661 15 8.38044 15 9.375V39.375" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
};

