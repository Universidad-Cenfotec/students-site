interface IconProps {
    className?: string;
    size?: number;
}

export const FileIcon: React.FC<IconProps> = ({ className = "", size = 45 }) => {
    return (
        <svg
            width={ size }
            height={ size }
            viewBox="0 0 45 45"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={ className }
        >
            <path d="M26.25 3.75H11.25C10.2554 3.75 9.30161 4.14509 8.59835 4.84835C7.89509 5.55161 7.5 6.50544 7.5 7.5V37.5C7.5 38.4946 7.89509 39.4484 8.59835 40.1516C9.30161 40.8549 10.2554 41.25 11.25 41.25H33.75C34.7446 41.25 35.6984 40.8549 36.4016 40.1516C37.1049 39.4484 37.5 38.4946 37.5 37.5V15L26.25 3.75Z" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M26.25 3.75V15H37.5" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M30 24.375H15" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M30 31.875H15" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M18.75 16.875H16.875H15" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
};

