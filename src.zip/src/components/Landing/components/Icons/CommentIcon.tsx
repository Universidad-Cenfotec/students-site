interface IconProps {
    className?: string;
    size?: number;
}

export const CommentIcon: React.FC<IconProps> = ({ className = "", size = 45 }) => {
    return (
        <svg
            width={ size }
            height={ size }
            viewBox="0 0 45 45"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={ className }
        >
            <path d="M38.75 21.9376C38.7565 24.4123 38.1783 26.8536 37.0625 29.0626C35.7396 31.7096 33.7058 33.936 31.189 35.4925C28.6722 37.0489 25.7717 37.8739 22.8125 37.8751C20.3377 37.8815 17.8965 37.3033 15.6875 36.1876L5 39.7501L8.5625 29.0626C7.44675 26.8536 6.86855 24.4123 6.875 21.9376C6.87615 18.9783 7.70115 16.0779 9.2576 13.5611C10.814 11.0443 13.0405 9.01049 15.6875 7.68755C17.8965 6.5718 20.3377 5.9936 22.8125 6.00005H23.75C27.6582 6.21566 31.3495 7.86523 34.1171 10.6329C36.8848 13.4006 38.5344 17.0919 38.75 21.0001V21.9376Z" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
};
