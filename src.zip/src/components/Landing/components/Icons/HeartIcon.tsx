interface IconProps {
    className?: string;
    size?: number;
}

export const HeartIcon: React.FC<IconProps> = ({ className = "", size = 45 }) => {
    return (
        <svg
            width={ size }
            height={ size }
            viewBox="0 0 45 45"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={ className }
        >
            <g clipPath="url(#clip0_4_110)">
                <path d="M38.1712 9.02217C37.2135 8.06406 36.0764 7.30401 34.825 6.78546C33.5735 6.2669 32.2321 6 30.8774 6C29.5228 6 28.1814 6.2669 26.9299 6.78546C25.6784 7.30401 24.5413 8.06406 23.5837 9.02217L21.5962 11.0097L19.6087 9.02217C17.6742 7.08775 15.0506 6.001 12.3149 6.001C9.57923 6.001 6.95559 7.08775 5.02117 9.02217C3.08675 10.9566 2 13.5802 2 16.3159C2 19.0516 3.08675 21.6753 5.02117 23.6097L7.00867 25.5972L21.5962 40.1847L36.1837 25.5972L38.1712 23.6097C39.1293 22.652 39.8893 21.515 40.4079 20.2635C40.9264 19.012 41.1933 17.6706 41.1933 16.3159C41.1933 14.9613 40.9264 13.6199 40.4079 12.3684C39.8893 11.1169 39.1293 9.97984 38.1712 9.02217Z" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            </g>
            <defs>
                <clipPath id="clip0_4_110">
                    <rect width="45" height="45" fill="currentColor" />
                </clipPath>
            </defs>
        </svg>
    );
};

